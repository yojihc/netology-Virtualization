#!/usr/bin/python

# Copyright: (c) 2026, Your Name <your.email@example.org>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = r'''
---
module: my_own_module

short_description: Create a text file with specific content

version_added: "1.0.0"

description: This module creates a text file on a remote host at a given path with specified content.

options:
    path:
        description: Target path where the file should be created.
        required: true
        type: str
    content:
        description: Text content to write into the file.
        required: true
        type: str

author:
    - Your Name (@yourGitHubHandle)
'''

EXAMPLES = r'''
# Create a simple text file
- name: Create a welcome file
  my_namespace.my_collection.my_own_module:
    path: /tmp/welcome.txt
    content: "Hello, Ansible World!"
'''

RETURN = r'''
path:
    description: The path to the file that was managed.
    type: str
    returned: always
    sample: '/tmp/welcome.txt'
msg:
    description: Status message execution result.
    type: str
    returned: always
    sample: 'File created successfully.'
'''

import os
from ansible.module_utils.basic import AnsibleModule


def run_module():
    # Шаг 1: Описываем входные параметры модуля
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=True)
    )

    result = dict(
        changed=False,
        path='',
        msg=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']
    result['path'] = path

    # Проверяем текущее состояние файла
    file_exists = os.path.exists(path)
    current_content = ""

    if file_exists:
        try:
            with open(path, 'r', encoding='utf-8') as f:
                current_content = f.read()
        except Exception as e:
            module.fail_json(msg=f"Failed to read existing file: {str(e)}", **result)

    # Определяем, нужны ли изменения
    if not file_exists or current_content != content:
        result['changed'] = True

    # Если запущен check_mode, выходим без внесения изменений
    if module.check_mode:
        if result['changed']:
            result['msg'] = "File would be created or modified."
        else:
            result['msg'] = "File is already up to date."
        module.exit_json(**result)

    # Шаг 2: Выполняем основную задачу (создание/обновление файла)
    if result['changed']:
        try:
            # Создаем родительские директории, если их нет
            dir_name = os.path.dirname(path)
            if dir_name and not os.path.exists(dir_name):
                os.makedirs(dir_name)

            # Записываем контент в файл
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            result['msg'] = "File written successfully."
        except Exception as e:
            module.fail_json(msg=f"Failed to write file: {str(e)}", **result)
    else:
        result['msg'] = "File is already in the desired state."

    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
